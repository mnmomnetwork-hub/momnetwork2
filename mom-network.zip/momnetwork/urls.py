from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    # HTML pages
    path("", include("apps.core.urls")),
    # APIs
    path("api/", include("apps.entries.urls")),
    path("api/", include("apps.stories.urls")),
    path("api/", include("apps.nominations.urls")),
    path("api/", include("apps.donations.urls")),
    path("api/", include("apps.contact.urls")),
    path("api/", include("apps.winners.urls")),
]
